#!/usr/bin/env python3
"""
JanitorAI Scrapper v4.1
"""
import os
import re
import sys
import time
import json
import threading
import subprocess

from flask import Flask, render_template, request, redirect, jsonify, Response, send_file
from flask_cors import CORS

from config import CARDS_DIR, ARCHIVE_DIR, HOST, PORT, DEBUG, APP_NAME, APP_VERSION
from utils import (
    generate_code, find_card_by_any_code,
    extract_tag_text, extract_character_name, sanitize, clean_desc,
    get_card_path, find_card_by_code, load_card, save_card, make_card,
    get_all_cards, get_archived_cards, move_to_archive, move_to_cards, delete_card,
    embed_png, download_and_convert_image, parse_messages
)

app = Flask(__name__)
CORS(app)

CLOUDFLARED_URL = None


# ============================================
# Cloudflared
# ============================================

def run_cloudflared():
    global CLOUDFLARED_URL
    try:
        process = subprocess.Popen(
            ["cloudflared", "tunnel", "--url", f"http://localhost:{PORT}", "--no-chunked-encoding"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1
        )
        for line in process.stdout:
            if "trycloudflare.com" in line:
                match = re.search(r'(https://[a-zA-Z0-9-]+\.trycloudflare\.com)', line)
                if match:
                    CLOUDFLARED_URL = match.group(1)
                    print(f"\n🌐 Tunnel: {CLOUDFLARED_URL}")
                    print(f"📡 API: {CLOUDFLARED_URL}/v1/chat/completions\n")
    except FileNotFoundError:
        print("❌ cloudflared not found!")
    except Exception as e:
        print(f"❌ Cloudflared error: {e}")


# ============================================
# Pages
# ============================================

@app.route("/")
def home():
    sort_by = request.args.get('sort', 'date_desc')
    cards = get_all_cards(sort_by)
    archived = get_archived_cards(sort_by)
    return render_template("home.html",
        cards=cards, archived=archived,
        tunnel_url=CLOUDFLARED_URL, current_sort=sort_by
    )


@app.route("/archive")
def archive_page():
    sort_by = request.args.get('sort', 'date_desc')
    return render_template("archive.html",
        cards=get_archived_cards(sort_by), current_sort=sort_by
    )


@app.route("/review/<filename>")
def review(filename):
    card_data = load_card(filename)
    if not card_data:
        return "Not found", 404

    d = card_data['data']
    ext = d.get('extensions', {})

    card = {
        "name": d.get("name", ""),
        "description": d.get("description", ""),
        "personality": d.get("personality", ""),
        "scenario": d.get("scenario", ""),
        "first_mes": d.get("first_mes", ""),
        "mes_example": d.get("mes_example", ""),
        "alternate_greetings": d.get("alternate_greetings", []),
        "tags": d.get("tags", []),
        "avatar_url": ext.get("janitor_avatar", ""),
        "creator_notes": d.get("creator_notes", ""),
        "code": ext.get("scrapper_code", "")
    }

    has_avatar = bool(card["avatar_url"])
    has_notes = bool(card["creator_notes"].strip())

    missing = []
    if not has_avatar: missing.append("Avatar")
    if not has_notes: missing.append("Notes")

    return render_template("review.html",
        card=card, file_name=filename,
        is_complete=has_avatar and has_notes,
        is_archived=card_data.get('_archived', False),
        missing=missing
    )


@app.route("/edit/<filename>", methods=["GET", "POST"])
def edit(filename):
    card_data = load_card(filename)
    if not card_data:
        return "Not found", 404

    is_archived = card_data.get('_archived', False)
    filepath = card_data.get('_filepath')

    if request.method == "POST":
        d = card_data['data']
        d['name'] = request.form.get('char_name', d['name'])
        d['description'] = request.form.get('description', d['description'])
        d['personality'] = request.form.get('personality', d.get('personality', ''))
        d['scenario'] = request.form.get('scenario', d.get('scenario', ''))
        d['first_mes'] = request.form.get('first_mes', d['first_mes'])
        d['mes_example'] = request.form.get('mes_example', d.get('mes_example', ''))
        d['tags'] = [t.strip() for t in request.form.get('tags', '').split(',') if t.strip()]
        d['creator'] = request.form.get('creator', '')
        d['creator_notes'] = request.form.get('notes', '')

        alt_count = int(request.form.get('alt_count', 0))
        alts = []
        for i in range(alt_count):
            alt = request.form.get(f'alt_{i}', '').strip()
            if alt:
                alts.append(alt)
        d['alternate_greetings'] = alts

        save_card(card_data, filepath)
        return redirect(f'/review/{filename}')

    d = card_data['data']
    d['code'] = d.get('extensions', {}).get('scrapper_code', '')
    return render_template("edit.html", card=d, file_name=filename, is_archived=is_archived)


@app.route("/png/<filename>", methods=["GET", "POST"])
def png_page(filename):
    card_data = load_card(filename)
    if not card_data:
        return "Not found", 404

    filepath = card_data.get('_filepath')

    if request.method == "POST":
        action = request.form.get('action')

        if action == 'parse':
            try:
                jai = json.loads(request.form.get('json_data', ''))
                avatar = f"https://ella.janitorai.com/bot-avatars/{jai['avatar']}" if jai.get('avatar') else ""
                tags = list(jai.get('custom_tags') or [])
                for t in (jai.get('tags') or []):
                    tag_name = re.sub(r'^[^\w]+', '', t.get('name', ''))
                    if tag_name and tag_name not in tags:
                        tags.append(tag_name)
                return render_template("png_final.html",
                    card=card_data['data'], file_name=filename,
                    avatar=avatar, tags=tags,
                    notes=jai.get('description', ''),
                    creator=jai.get('creator_name', '')
                )
            except:
                return "Invalid JSON", 400

        elif action == 'direct':
            avatar = request.form.get('avatar_url', '').strip()
            if avatar:
                d = card_data['data']
                return render_template("png_final.html",
                    card=d, file_name=filename, avatar=avatar,
                    tags=d.get('tags', []),
                    notes=d.get('creator_notes', ''),
                    creator=d.get('creator', '')
                )
            return "No URL", 400

        elif action == 'download':
            avatar = request.form.get('avatar_url', '').strip()
            if not avatar:
                return "No avatar", 400

            d = card_data['data']
            d['name'] = request.form.get('char_name', d['name'])
            d['description'] = request.form.get('description', d['description'])
            d['scenario'] = request.form.get('scenario', d.get('scenario', ''))
            d['first_mes'] = request.form.get('first_mes', d['first_mes'])
            d['tags'] = [t.strip() for t in request.form.get('tags', '').split(',') if t.strip()]
            d['creator'] = request.form.get('creator', '')
            d['creator_notes'] = request.form.get('creator_notes', '')
            d['extensions']['janitor_avatar'] = avatar

            save_card(card_data, filepath)

            png = download_and_convert_image(avatar)
            if not png:
                return "Download failed", 400

            result = embed_png(png, card_data)
            if not result:
                return "Embed failed", 400

            return Response(result, mimetype='image/png',
                headers={'Content-Disposition': f'attachment; filename={sanitize(d["name"])}.png'})

    d = card_data['data']
    return render_template("png.html",
        card=d, file_name=filename,
        existing_avatar=d.get('extensions', {}).get('janitor_avatar', '')
    )


# ============================================
# Card Actions
# ============================================

@app.route("/archive-card/<filename>")
def archive_card(filename):
    if move_to_archive(filename):
        return redirect('/')
    return "Not found", 404


@app.route("/unarchive/<filename>")
def unarchive_card(filename):
    if move_to_cards(filename):
        return redirect('/archive')
    return "Not found", 404


@app.route("/delete/<filename>")
def delete(filename):
    delete_card(filename)
    ref = request.referrer or '/'
    return redirect('/archive' if '/archive' in ref else '/')


@app.route("/dl/<filename>")
def download_json(filename):
    card = load_card(filename)
    if card:
        return send_file(card['_filepath'], as_attachment=True, download_name=f"{filename}.json")
    return "Not found", 404


@app.route("/reset")
def reset():
    for f in os.listdir(CARDS_DIR):
        if f.endswith('.json'):
            os.remove(os.path.join(CARDS_DIR, f))
    return redirect('/')


@app.route("/reset-archive")
def reset_archive():
    for f in os.listdir(ARCHIVE_DIR):
        if f.endswith('.json'):
            os.remove(os.path.join(ARCHIVE_DIR, f))
    return redirect('/archive')


# ============================================
# Alt Greeting Management
# ============================================

@app.route("/add-alt/<filename>", methods=["POST"])
def add_alt(filename):
    """Manually add alt greeting."""
    card_data = load_card(filename)
    if not card_data:
        return "Not found", 404

    alt_text = request.form.get('alt_text', '').strip()
    if alt_text:
        card_data['data'].setdefault('alternate_greetings', []).append(alt_text)
        save_card(card_data)

    return redirect(f'/review/{filename}')


@app.route("/delete-alt/<filename>/<int:index>")
def delete_alt(filename, index):
    """Delete specific alt greeting."""
    card_data = load_card(filename)
    if not card_data:
        return "Not found", 404

    alts = card_data['data'].get('alternate_greetings', [])
    if 0 <= index < len(alts):
        alts.pop(index)
        card_data['data']['alternate_greetings'] = alts
        save_card(card_data)

    return redirect(f'/review/{filename}')


# ============================================
# API
# ============================================

@app.route("/v1/models")
def models():
    return jsonify({"object": "list", "data": [{"id": "mock-model", "object": "model"}]})


@app.route('/v1/chat/completions', methods=['POST'])
def chat():
    try:
        data = request.get_json(force=True)
    except:
        return jsonify({"error": "Invalid JSON"}), 400

    messages = data.get("messages", [])
    raw, first = parse_messages(messages)

    if not raw:
        return jsonify({
            "id": "0", "object": "chat.completion", "created": int(time.time()),
            "model": "mock-model",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": "Hello!"}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        })

    name = extract_character_name(raw) or "Unknown"
    print(f"👤 {name}")

    # Scan ALL text for existing code
    all_text = raw + " " + first
    for msg in messages:
        all_text += " " + msg.get("content", "")

    # Check if code exists (ONLY in cards/, NOT archive)
    existing_card, found_code = find_card_by_any_code(all_text)

    # Replace placeholders
    raw = raw.replace("[Persona Name]", "{{user}}")
    first = first.replace("[Persona Name]", "{{user}}")

    desc = clean_desc(raw)
    example = extract_tag_text(raw, "example_dialogs") or ""
    scenario = extract_tag_text(raw, "Scenario") or ""

    reply = ""

    if existing_card and found_code:
        # Add alt greeting to existing card
        alts = existing_card["data"].get("alternate_greetings", [])
        all_greetings = [existing_card["data"]["first_mes"].strip().lower()] + [a.strip().lower() for a in alts]

        if first.strip().lower() not in all_greetings:
            alts.append(first)
            existing_card["data"]["alternate_greetings"] = alts
            save_card(existing_card)
            alt_num = len(alts)
            reply = f"✅ Alt greeting #{alt_num} saved for {name}\n📋 Code: {found_code}"
            print(f"✅ Alt #{alt_num} for {name} ({found_code})")
        else:
            reply = f"⏭️ Greeting already exists for {name}, skipped."
            print(f"⏭️ Skipped {name}")
    else:
        # Create new card
        new_code = generate_code()
        card = make_card(name, desc, first, new_code, example, scenario)

        filepath = get_card_path(name, new_code, archived=False)
        card['_filepath'] = filepath
        save_card(card, filepath)

        reply = f"✅ New card: {name} created!\n📋 Alt code: {new_code}"
        print(f"✅ New: {name} ({new_code})")

    return jsonify({
        "id": "0", "object": "chat.completion", "created": int(time.time()),
        "model": "mock-model",
        "choices": [{"index": 0, "message": {"role": "assistant", "content": reply}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    })


# ============================================
# Main
# ============================================

if __name__ == '__main__':
    print(f"\n{'='*40}")
    print(f"🧹 {APP_NAME} v{APP_VERSION}")
    print(f"{'='*40}")

    tunnel_thread = threading.Thread(target=run_cloudflared, daemon=True)
    tunnel_thread.start()
    time.sleep(2)

    print(f"🌐 http://localhost:{PORT}\n")
    app.run(host=HOST, port=PORT, debug=DEBUG, threaded=True)
