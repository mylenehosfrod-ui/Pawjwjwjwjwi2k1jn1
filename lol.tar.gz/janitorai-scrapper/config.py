"""
Configuration settings for JanitorAI Scrapper
"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CARDS_DIR = os.path.join(BASE_DIR, "cards")
ARCHIVE_DIR = os.path.join(BASE_DIR, "archive")

HOST = "0.0.0.0"
PORT = 5000
DEBUG = False

APP_NAME = "JanitorAI Scrapper"
APP_VERSION = "4.1"

os.makedirs(CARDS_DIR, exist_ok=True)
os.makedirs(ARCHIVE_DIR, exist_ok=True)
