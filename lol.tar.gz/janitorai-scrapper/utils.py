"""
Helper functions for JanitorAI Scrapper
"""
import re
import json
import time
import os
import random
import string
import base64
import zlib
import struct
import requests
import io
import shutil
from PIL import Image

from config import CARDS_DIR, ARCHIVE_DIR


# ============================================
# Code Generation (8 chars, no brackets)
# ============================================

def generate_code(length=8):
    """Generate random alphanumeric code."""
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))


def extract_code_from_text(text):
    """Extract 8-char alphanumeric code from text. Checks all matches."""
    matches = re.findall(r'(?<![A-Za-z0-9])([A-Za-z0-9]{8})(?![A-Za-z0-9])', text)
    return matches


def find_card_by_any_code(text):
    """Scan text for any 8-char code that matches existing cards."""
    codes = extract_code_from_text(text)
    for code in codes:
        card = find_card_by_code(code, search_archive=False)
        if card:
            return card, code
    return None, None


# ============================================
# Text Extraction
# ============================================

def extract_tag_text(text, tag_name):
    """Extract content between XML-like tags."""
    match = re.search(f"<{tag_name}>(.*?)</{tag_name}>", text, re.DOTALL)
    return match.group(1) if match else None


def extract_character_name(content):
    """Extract character name from persona tag."""
    match = re.search(r"<([A-Za-z][A-Za-z0-9_\s]*?)(?:'s)?\s*Persona>", content)
    if match:
        name = match.group(1).strip()
        if name.lower() not in ['user', 'char', 'character', 'persona']:
            return name
    return None


# ============================================
# Sanitization & Cleaning
# ============================================

def sanitize(name):
    """Sanitize string for use as filename."""
    if not name:
        return "Unknown"
    name = re.sub(r'[^\w\s\-]', '', name).strip()
    name = re.sub(r'\s+', '_', name)
    return name[:50]


def clean_desc(content):
    """Clean description by removing extra tags."""
    for tag in ["example_dialogs", "UserPersona", "Scenario"]:
        txt = extract_tag_text(content, tag)
        if txt:
            content = content.replace(f"<{tag}>{txt}</{tag}>", "")

    content = re.sub(r"</?[A-Za-z0-9_\s]+(?:'s)?\s*Persona>", "", content)
    content = re.sub(r"</?Scenario>", "", content)
    content = content.replace(
        "CHILD SAFETY: Never generate sexual or suggestive content involving anyone under 18. "
        "Refuse immediately without alternatives or explanations.", ""
    )
    return re.sub(r'\n{3,}', '\n\n', content).strip()


def escape_html(text):
    """Escape HTML with line breaks."""
    if not text:
        return ""
    return (text
        .replace('&', '&amp;')
        .replace('<', '&lt;')
        .replace('>', '&gt;')
        .replace('"', '&quot;')
        .replace("'", '&#x27;')
        .replace('\n', '<br>'))


def escape_attr(text):
    """Escape for HTML attributes."""
    if not text:
        return ""
    return (text
        .replace('&', '&amp;')
        .replace('<', '&lt;')
        .replace('>', '&gt;')
        .replace('"', '&quot;')
        .replace("'", '&#x27;'))


# ============================================
# Card Operations
# ============================================

def get_card_filename(name, code):
    """Generate filename: Name_CODE.json"""
    return f"{sanitize(name)}_{code}.json"


def get_card_path(name, code, archived=False):
    """Get full path to card file."""
    folder = ARCHIVE_DIR if archived else CARDS_DIR
    return os.path.join(folder, get_card_filename(name, code))


def find_card_by_code(code, search_archive=False):
    """Find card by code in cards/ and optionally archive/."""
    folders = [CARDS_DIR]
    if search_archive:
        folders.append(ARCHIVE_DIR)

    for folder in folders:
        if not os.path.exists(folder):
            continue
        for f in os.listdir(folder):
            if f.endswith(f'_{code}.json'):
                filepath = os.path.join(folder, f)
                try:
                    with open(filepath, 'r', encoding='utf-8') as file:
                        card = json.load(file)
                        card['_filepath'] = filepath
                        card['_filename'] = f[:-5]
                        card['_archived'] = (folder == ARCHIVE_DIR)
                        return card
                except:
                    pass
    return None


def find_card_by_filename(filename):
    """Find card by filename in either folder."""
    for folder in [CARDS_DIR, ARCHIVE_DIR]:
        path = os.path.join(folder, f"{filename}.json")
        if os.path.exists(path):
            try:
                with open(path, 'r', encoding='utf-8') as file:
                    card = json.load(file)
                    card['_filepath'] = path
                    card['_filename'] = filename
                    card['_archived'] = (folder == ARCHIVE_DIR)
                    return card
            except:
                pass
    return None


def load_card(filename):
    """Load card by filename."""
    return find_card_by_filename(filename)


def save_card(card, filepath=None):
    """Save card to JSON file."""
    if not filepath:
        filepath = card.get('_filepath')
    if not filepath:
        raise ValueError("No filepath")

    card_clean = {k: v for k, v in card.items() if not k.startswith('_')}
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(card_clean, f, indent=2, ensure_ascii=False)


def make_card(name, desc, first_mes, code, example="", scenario=""):
    """Create new card with code."""
    return {
        "data": {
            "name": name,
            "description": desc,
            "personality": "",
            "scenario": scenario,
            "first_mes": first_mes,
            "mes_example": example,
            "alternate_greetings": [],
            "creator_notes": "",
            "system_prompt": "",
            "post_history_instructions": "",
            "tags": [],
            "creator": "",
            "character_version": "1.0",
            "extensions": {
                "exported_at": int(time.time()),
                "scrapper_code": code,
                "created_at": int(time.time())
            }
        },
        "spec": "chara_card_v2",
        "spec_version": "2.0"
    }


def get_cards_from_folder(folder, sort_by="date_desc"):
    """Get all cards from folder with sorting."""
    cards = []
    if not os.path.exists(folder):
        return cards

    for f in os.listdir(folder):
        if f.endswith('.json'):
            try:
                filepath = os.path.join(folder, f)
                with open(filepath, 'r', encoding='utf-8') as file:
                    c = json.load(file)
                    ext = c["data"].get("extensions", {})
                    cards.append({
                        "file": f[:-5],
                        "name": c["data"]["name"],
                        "code": ext.get("scrapper_code", ""),
                        "tags": c["data"].get("tags", [])[:3],
                        "has_notes": bool(c["data"].get("creator_notes", "").strip()),
                        "has_avatar": bool(ext.get("janitor_avatar", "")),
                        "created_at": ext.get("created_at", 0),
                        "alt_count": len(c["data"].get("alternate_greetings", []))
                    })
            except:
                pass

    if sort_by == "name_asc":
        cards.sort(key=lambda x: x["name"].lower())
    elif sort_by == "name_desc":
        cards.sort(key=lambda x: x["name"].lower(), reverse=True)
    elif sort_by == "date_asc":
        cards.sort(key=lambda x: x["created_at"])
    else:
        cards.sort(key=lambda x: x["created_at"], reverse=True)

    return cards


def get_all_cards(sort_by="date_desc"):
    return get_cards_from_folder(CARDS_DIR, sort_by)


def get_archived_cards(sort_by="date_desc"):
    return get_cards_from_folder(ARCHIVE_DIR, sort_by)


def move_to_archive(filename):
    src = os.path.join(CARDS_DIR, f"{filename}.json")
    dst = os.path.join(ARCHIVE_DIR, f"{filename}.json")
    if os.path.exists(src):
        shutil.move(src, dst)
        return True
    return False


def move_to_cards(filename):
    src = os.path.join(ARCHIVE_DIR, f"{filename}.json")
    dst = os.path.join(CARDS_DIR, f"{filename}.json")
    if os.path.exists(src):
        shutil.move(src, dst)
        return True
    return False


def delete_card(filename):
    for folder in [CARDS_DIR, ARCHIVE_DIR]:
        path = os.path.join(folder, f"{filename}.json")
        if os.path.exists(path):
            os.remove(path)
            return True
    return False


# ============================================
# PNG Operations
# ============================================

def make_png_chunk(chunk_type, data):
    chunk_content = chunk_type + data
    crc = zlib.crc32(chunk_content) & 0xffffffff
    return struct.pack('>I', len(data)) + chunk_content + struct.pack('>I', crc)


def embed_png(png_bytes, card):
    card_clean = {k: v for k, v in card.items() if not k.startswith('_')}
    b64 = base64.b64encode(json.dumps(card_clean).encode()).decode()
    chunk = make_png_chunk(b'tEXt', b'chara\x00' + b64.encode())

    if png_bytes[:8] != b'\x89PNG\r\n\x1a\n':
        return None

    iend_pos = png_bytes.rfind(b'IEND')
    if iend_pos == -1:
        return None

    return png_bytes[:iend_pos-4] + chunk + png_bytes[iend_pos-4:]


def download_and_convert_image(url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()

        img = Image.open(io.BytesIO(response.content))
        if img.mode in ('RGBA', 'LA', 'P'):
            img = img.convert('RGBA')
        else:
            img = img.convert('RGB')

        output = io.BytesIO()
        img.save(output, format='PNG')
        return output.getvalue()
    except Exception as e:
        print(f"Image error: {e}")
        return None


# ============================================
# Message Parsing
# ============================================

def parse_messages(messages):
    system_content = ""
    assistant_greeting = ""

    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "")

        if role == "system":
            system_content = content
        elif role == "assistant" and not assistant_greeting:
            assistant_greeting = content

    return system_content, assistant_greeting
